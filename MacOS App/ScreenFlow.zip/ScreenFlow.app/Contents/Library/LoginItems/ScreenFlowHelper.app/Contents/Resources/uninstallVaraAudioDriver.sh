#!/bin/sh

# uinstall the driver by moving to a temp directory, and rm -rf on that tmp dir.

export INST=/System/Library/Extensions/TelestreamAudio.kext

if test -d "$INST" ; then  
    # two times, because sometimes one is not enough, unfortunately.
    kextunload $INST
    sleep 1
    kextunload $INST
    
    # mv is atomic, do not run rm -rf on /System/Library with admin privs...
    rm -rf /tmp/com_vara_VaraAudioDriver_delete_me
    mv $INST /tmp/com_vara_VaraAudioDriver_delete_me
    rm -rf /tmp/com_vara_VaraAudioDriver_delete_me
fi

export INST=/System/Library/Extensions/VaraAudio.kext

if test -d "$INST" ; then  
    # two times, because sometimes one is not enough, unfortunately.
    kextunload $INST
    sleep 1
    kextunload $INST
    
    # mv is atomic, do not run rm -rf on /System/Library with admin privs...
    rm -rf /tmp/com_vara_VaraAudioDriver_delete_me
    mv $INST /tmp/com_vara_VaraAudioDriver_delete_me
    rm -rf /tmp/com_vara_VaraAudioDriver_delete_me
fi

export INST=/Library/Extensions/TelestreamAudio.kext

if test -d "$INST" ; then  
    # two times, because sometimes one is not enough, unfortunately.
    kextunload $INST
    sleep 1
    kextunload $INST
    
    # mv is atomic, do not run rm -rf on /System/Library with admin privs...
    rm -rf /tmp/com_vara_VaraAudioDriver_delete_me
    mv $INST /tmp/com_vara_VaraAudioDriver_delete_me
    rm -rf /tmp/com_vara_VaraAudioDriver_delete_me
fi