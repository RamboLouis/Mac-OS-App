uniform sampler2DRect	samplerA;
uniform sampler3D		lut;

void main()
{
	vec4			color		=	texture2DRect(samplerA, vec2(gl_TexCoord[0]));
	vec3			corrected	=	texture3D(lut, color.bgr).rgb;
	gl_FragColor				=	vec4(corrected, color.a) * gl_Color;
}
